import { Ingredient, ShoppingItem } from '../types/ingredient';

const API_BASE_URL = 'http://localhost:8080/api';

// 인증 헤더 가져오기
function getAuthHeaders(): HeadersInit {
  const token = localStorage.getItem('authToken');
  return {
    'Content-Type': 'application/json',
    ...(token && { Authorization: `Bearer ${token}` }),
  };
}

class IngredientStore {
  private listeners: Set<() => void> = new Set();
  private ingredientsCache: Ingredient[] = [];
  private shoppingListCache: ShoppingItem[] = [];

  // 식재료 가져오기
  async fetchIngredients(): Promise<Ingredient[]> {
    try {
      const response = await fetch(`${API_BASE_URL}/ingredients`, {
        headers: getAuthHeaders(),
      });

      if (response.ok) {
        const data = await response.json();
        this.ingredientsCache = data.map((item: any) => ({
          ...item,
          expiryDate: new Date(item.expiryDate),
          purchaseDate: new Date(item.purchaseDate),
        }));
        this.notifyListeners();
        return this.ingredientsCache;
      }
    } catch (error) {
      console.error('식재료 조회 오류:', error);
    }
    return this.ingredientsCache;
  }

  // 캐시된 식재료 반환 (동기)
  getIngredients(): Ingredient[] {
    return this.ingredientsCache;
  }

  // 식재료 추가
  async addIngredient(ingredient: Omit<Ingredient, 'id'>): Promise<void> {
    try {
      const response = await fetch(`${API_BASE_URL}/ingredients`, {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({
          name: ingredient.name,
          category: ingredient.category,
          quantity: ingredient.quantity,
          unit: ingredient.unit,
          storage: ingredient.storage,
          purchaseDate: ingredient.purchaseDate.toISOString().split('T')[0],
          expiryDate: ingredient.expiryDate.toISOString().split('T')[0],
        }),
      });

      if (response.ok) {
        await this.fetchIngredients();
      } else {
        throw new Error('식재료 추가 실패');
      }
    } catch (error) {
      console.error('식재료 추가 오류:', error);
      throw error;
    }
  }

  // 식재료 수정
  async updateIngredient(id: string, updates: Partial<Ingredient>): Promise<void> {
    try {
      const updateData: any = { ...updates };
      if (updates.purchaseDate) {
        updateData.purchaseDate = updates.purchaseDate.toISOString().split('T')[0];
      }
      if (updates.expiryDate) {
        updateData.expiryDate = updates.expiryDate.toISOString().split('T')[0];
      }

      const response = await fetch(`${API_BASE_URL}/ingredients/${id}`, {
        method: 'PUT',
        headers: getAuthHeaders(),
        body: JSON.stringify(updateData),
      });

      if (response.ok) {
        await this.fetchIngredients();
      } else {
        throw new Error('식재료 수정 실패');
      }
    } catch (error) {
      console.error('식재료 수정 오류:', error);
      throw error;
    }
  }

  // 식재료 삭제
  async deleteIngredient(id: string): Promise<void> {
    try {
      const response = await fetch(`${API_BASE_URL}/ingredients/${id}`, {
        method: 'DELETE',
        headers: getAuthHeaders(),
      });

      if (response.ok) {
        await this.fetchIngredients();
      } else {
        throw new Error('식재료 삭제 실패');
      }
    } catch (error) {
      console.error('식재료 삭제 오류:', error);
      throw error;
    }
  }

  // 장보기 리스트 가져오기
  async fetchShoppingList(): Promise<ShoppingItem[]> {
    try {
      const response = await fetch(`${API_BASE_URL}/shopping-list`, {
        headers: getAuthHeaders(),
      });

      if (response.ok) {
        const data = await response.json();
        this.shoppingListCache = data;
        this.notifyListeners();
        return this.shoppingListCache;
      }
    } catch (error) {
      console.error('장보기 리스트 조회 오류:', error);
    }
    return this.shoppingListCache;
  }

  // 캐시된 장보기 리스트 반환 (동기)
  getShoppingList(): ShoppingItem[] {
    return this.shoppingListCache;
  }

  // 장보기 항목 추가
  async addShoppingItem(name: string, quantity: number, unit: string): Promise<void> {
    try {
      const response = await fetch(`${API_BASE_URL}/shopping-list`, {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({ name, quantity, unit, checked: false }),
      });

      if (response.ok) {
        await this.fetchShoppingList();
      } else {
        throw new Error('장보기 항목 추가 실패');
      }
    } catch (error) {
      console.error('장보기 항목 추가 오류:', error);
      throw error;
    }
  }

  // 장보기 항목 토글
  async toggleShoppingItem(id: string): Promise<void> {
    try {
      const item = this.shoppingListCache.find((i) => i.id === id);
      if (!item) return;

      const response = await fetch(`${API_BASE_URL}/shopping-list/${id}`, {
        method: 'PUT',
        headers: getAuthHeaders(),
        body: JSON.stringify({ ...item, checked: !item.checked }),
      });

      if (response.ok) {
        await this.fetchShoppingList();
      } else {
        throw new Error('장보기 항목 토글 실패');
      }
    } catch (error) {
      console.error('장보기 항목 토글 오류:', error);
      throw error;
    }
  }

  // 장보기 항목 삭제
  async deleteShoppingItem(id: string): Promise<void> {
    try {
      const response = await fetch(`${API_BASE_URL}/shopping-list/${id}`, {
        method: 'DELETE',
        headers: getAuthHeaders(),
      });

      if (response.ok) {
        await this.fetchShoppingList();
      } else {
        throw new Error('장보기 항목 삭제 실패');
      }
    } catch (error) {
      console.error('장보기 항목 삭제 오류:', error);
      throw error;
    }
  }

  // 구독
  subscribe(listener: () => void): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  // 리스너 알림
  private notifyListeners(): void {
    this.listeners.forEach((listener) => listener());
  }
}

export const ingredientStore = new IngredientStore();
