export type StorageType = '냉장' | '냉동' | '실온';
export type CategoryType = 'vegetable' | 'meat' | 'dairy' | 'grain' | 'seafood' | 'fruit' | 'etc';

export interface Ingredient {
  id: string;
  name: string;
  category: CategoryType;
  quantity: number;
  unit: string;
  storage: StorageType;
  expirationDate: Date;
  purchaseDate: Date;
}

export interface ShoppingItem {
  id: string;
  name: string;
  quantity: number;
  unit: string;
  checked: boolean;
}
